<?php

/* @var $this yii\web\View */
use yii\helpers\Url;

$this->title = 'MCS Ticketing System';
?>
<div class="site-index">

    <div class="jumbotron">

        <p class="lead">Welcome to MCS Task Ticketing System</p>

        <p><a class="btn btn-lg btn-success" href="<?= Url::to(['site/login']); ?>">Login to Ticketing System</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Ticket Dashboard</h2>

                <p>Team members can view the tickets assigned to them, and can be order via status or due date.</p>

            </div>
            <div class="col-lg-4">
                <h2>Manage Tickets</h2>

                <p>Aside from usual ticket information, team members can now add comments and add attachments to each task to streamline work.</p>

            </div>
            <div class="col-lg-4">
                <h2>Create Reports</h2>

                <p>Management can create reports that will provide list of finished tasks per week, as well as other
                   pertinent work information that they will need.</p>

            </div>
        </div>

    </div>
</div>
