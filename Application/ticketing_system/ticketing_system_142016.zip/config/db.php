<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=ticketing_mcs',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
