<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=sparksit_ticketing',
    'username' => 'sparksit_ticket',
    'password' => 'sparksit_ticket',
    'charset' => 'utf8',
];
